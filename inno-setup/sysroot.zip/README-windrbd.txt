This directory contains the '/' directory of the WinDRBD user
space utilities. The path is currently hard coded, so please
do not rename or move this folder.

For the binary distribution, the windrbd utils binaries are installed
to C:\Program Files\WinDRBD . This directory is also added to the
PATH variable (you might have to restart your shell after WinDRBD
installation).

There is no need to install CygWin with WinDRBD, since windrbd binary
distribution comes with a bundled cygwin DLL. You might have to
replace it later if you install cygwin later (cygwin will complain
about the bundled DLL).
