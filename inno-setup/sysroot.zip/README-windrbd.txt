For the binary distribution, the windrbd utils binaries are installed
to C:\Windows\System32 (so you don't need to alter the PATH variable).

There is no need to install CygWin with windrbd, since windrbd binary
distribution comes with a bundled cygwin DLL. You might have to
replace it later if you install cygwin later (cygwin will complain
about the bundled DLL).
